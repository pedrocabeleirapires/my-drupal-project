/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.barrio_Custum = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
